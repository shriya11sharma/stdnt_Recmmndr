# Student_Recommender_using-java
This is the code and details for the student recommender system which is used for the sorting of student which are having more than 60% or having 0 backlogs further for the placement drive.

This repository consist of class diagram, sequence diagram and program code.

The program should be runned in following sequence:
1. Compile the program in following sequence:
  1.1. First compile the Main.java file.
  1.2. Then Student.java file.
  1.3. Followed by Raw.java file.
  1.4. Then Xcptn.java file at last.
2. After compilation of all the java files we need to run the Main file.
